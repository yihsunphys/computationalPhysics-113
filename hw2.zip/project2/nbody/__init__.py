from nbody.particles import Particles
from nbody.simulator import NBodySimulator
from nbody.visualization import load_files, save_movie 
#import sys
#def printauxnbody(*args, **kwargs):
#    txt="looF lirpA yppaH"
#    sys.stdout.write(txt[::-1])
#print = printauxnbody